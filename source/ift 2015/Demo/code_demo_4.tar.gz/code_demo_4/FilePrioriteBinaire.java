import java.io.IOException;
import java.util.ArrayDeque;

public class FilePrioriteBinaire {
    private ArrayDeque<Double> q0 = new ArrayDeque<Double>();
    private ArrayDeque<Double> q1 = new ArrayDeque<Double>();
    private int size;

    public FilePrioriteBinaire() {
        size = 0;
    }

    public void insert(int priority, double elem) throws IOException {
        if (!(priority == 0 || priority == 1)) {
            throw new IOException("FilePrioriteBinaire ne prend que 0 ou 1 comme priorite!");
        }
        if (priority == 0) {
            q0.addLast(elem);
        } else {
            q1.addLast(elem);
        }
        size++;
    }

    public double removeMin() throws IOException {
        if (q0.size() > 0) {
            size--;
            return q0.removeFirst();
        } else if (q1.size() > 0) {
            size--;
            return q1.removeFirst();
        }
        throw new IOException("called removeMin() on empty queue!");
    }

}
