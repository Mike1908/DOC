import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;


public class Demo4 {


    public static void main(String[] args) throws IOException {
        TasBinaireSentinelles h = new TasBinaireSentinelles();
        int[] values = new int[]{4,7,2,9,7,4,1};


        //Exercice pq.1
//        System.out.println("\n***Exercice pq.1***");
//        for (int i =0; i<values.length; i++) {
//            h.insert(new Item((double) values[i], (double) i));
//        }
//        System.out.println(h.pretty_print());
//        for (int i = 0; i < 6; i++) {
//            h.deleteMin();
//            System.out.println();
//            System.out.println(h.pretty_print());
//        }


        //Exercice pq.2
        System.out.println("\n***Exercice pq.2***");
        h = new TasBinaireSentinelles();
        for (int i =0; i<values.length; i++) {
            h.insert(new Item((double) values[i], (double) i));
        }
        System.out.println(h.pretty_print());

        System.out.println("plus petits que 4.0 :" + h.plus_petits(4.0));


        //Exercice pq.3
//        System.out.println("\n***Exercice pq.3***");
//        FilePrioriteBinaire fpb = new FilePrioriteBinaire();
//        for (int i=1; i<6; i++) {
//            int p = ThreadLocalRandom.current().nextInt(0, 2);
//            fpb.insert(p, (double) i);
//            System.out.print("(" + p + "," + (double) i + ") ");
//        }
//        System.out.println();
//        for (int i=1; i<6; i++) {
//            System.out.println(fpb.removeMin());
//        }


//        //Exercice pq.4
//        System.out.println("\n***Exercice pq.4***");
//
//
//        //Exercice pq.5
//        System.out.println("\n***Exercice pq.5***");
//
//
//        //Exercice pq.6
//        System.out.println("\n***Exercice pq.6***");



    }
}
