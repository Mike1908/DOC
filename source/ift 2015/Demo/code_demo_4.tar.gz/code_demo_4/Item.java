
public class Item {

    private double priority;
    private double element;

    public Item(double p, double e) {
        priority = p;
        element = e;
    }

    public double priority() {
        return priority;
    }

    public double elem() {
        return element;
    }

    public void setPriority(double p) {
        priority = p;
    }

    public void setElement(double e) {
        element = e;
    }
}
