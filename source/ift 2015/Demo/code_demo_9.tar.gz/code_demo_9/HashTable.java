import java.io.IOException;

public class HashTable {

    public int capacity;
    public int n;
    public double[] table;

    public HashTable(int c) {
        capacity = c;
        n = 0;
        table = new double[capacity];
        for (int i = 0; i < capacity; i ++) {
            table[i] = Double.NaN;
        }
    }

    public int hash_function(double x) {
        return (int) Math.floor(capacity * x);
    }

    public void insert(double x) throws IOException {
        int h = hash_function(x);
        n++;
        if (n > capacity) {
            throw new IOException("inserted in full HashTable!");
        }
        while (!Double.isNaN(table[h])) {
            h = (h + 1) % capacity;
        }
        table[h] = x;
    }
}
