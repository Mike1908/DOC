import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.concurrent.ThreadLocalRandom;


public class Demo9 {

    public static int bad_hash_fct(int x) {
        return (int)((Math.pow(x,2) + 1) % 11);
    }

    public static double[] get_random_array(int n) {
        double[] array = new double[n];
        for (int i = 0; i < n; i++) {
            array[i] = ThreadLocalRandom.current().nextDouble(0, 1);
        }
        return array;
    }

    public static void hash_sort(double[] F) throws IOException {
        HashTable G = new HashTable(2*F.length);
        for (double d : F) {
            G.insert(d);
        }
        int i = 0;
        int j;
        for (double d : G.table) {
            if (!Double.isNaN(d)) {
                F[i] = d;
                j = i;
                while (j > 0 && F[j-1] > F[j]) {
                    swap(F, j, j-1);
                    j--;
                }
                i++;
            }
        }
    }

    public static void swap(double[] F, int i, int j) {
        double tmp = F[i];
        F[i] = F[j];
        F[j] = tmp;
    }

    public static void main(String[] args) throws IOException {
        // Exercice h.0/exercice_B_1, mauvaise fonction de hachage
        System.out.println("Exercice h.0/exercice_B, mauvaise fonction de hachage");
        HashSet<Integer> image = new HashSet<>();
        for (int i = -10000; i < 10000; i++) {
            image.add(bad_hash_fct(i));
        }
        System.out.println("Image de la fonction pour nombres de -10 000 à 10 000:");
        for (int x : image) {
            System.out.println(x);
        }
        System.out.println("Voici donc la démonstration que cette fonction de hachage n'utilise pas toute son image.");

        // Exercice h.4
        System.out.println("\nExercice h.4");
        double[] F = get_random_array(10);
        System.out.println("tableau F: " + Arrays.toString(F));
        hash_sort(F);
        System.out.println("trié : " + Arrays.toString(F));


    }
}
