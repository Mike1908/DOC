import java.io.IOException;

public class SinglyLinkedList {
    private SinglyLinkedNode head;
    private SinglyLinkedNode last;
    private int size;

    public SinglyLinkedList() {
        head = null;
        size = 0;
        last = null;
    }

    public SinglyLinkedList(SinglyLinkedNode firstNode) throws IOException {
        head = firstNode;
        if (head == null) {
            size = 0;
            return;
        }
        size = 1;
        SinglyLinkedNode p = head;
        while (p.next() != null && p.next() != head) {
            size++;
            p = p.next();
        }
        if (p.next() == head) {
            throw new IOException("Tried to construct SinglyLinkedList from node part of a circular list!");
        }
        last = p;
    }

    public void addFirst(int element) {
        SinglyLinkedNode tmp = head;
        head = new SinglyLinkedNode(element, tmp);
        size++;
        if (size == 1) {
            last = head;
        }
    }

    public void addFirst(SinglyLinkedNode node) {
        SinglyLinkedNode tmp = head;
        head = node;
        head.setNext(tmp);
        size++;
    }

    public void addLast(int x) throws IOException {
        addLast(new SinglyLinkedNode(x));
    }

    public void addLast(SinglyLinkedNode node) throws IOException {
        if (last == null) {
            if (head != null) {
                throw new IOException("last = null but head != null in SinglyLinkedList instance");
            }
            head = node;
            head.setNext(null);
            last = head;
            size = 1;
            return;
        }
        SinglyLinkedNode tmp = last;
        last = node;
        tmp.setNext(node);
        last.setNext(null);
        size++;
        if (size == 1) {
            head = last;
        }
    }

    public SinglyLinkedNode removeFirst() throws IOException {
        if (size <= 0) {
            throw new IOException("removeFirst() called on empy list");
        }
        SinglyLinkedNode node = head;
        head = head.next();
        size--;
        return node;
    }

//    public void addListLast(SinglyLinkedList list) {
//        last.setNext(list.head());
//        int newsize = size + list.size();
//
//    }

    public SinglyLinkedNode head() {
        return head;
    }

    public int size() {
        return size;
    }



}
