import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Stack;

public class Demo6 {

    public static SinglyLinkedNode[] split(SinglyLinkedNode n) {
        if (n == null || n.next() == null) {
            return new SinglyLinkedNode[]{n, null};
        }
        SinglyLinkedNode[] L0L1 = split(n.next().next());
        SinglyLinkedNode L0 = n;
        SinglyLinkedNode L1 = n.next();
        L0.setNext(L0L1[0]);
        L1.setNext((L0L1[1]));
        return new SinglyLinkedNode[]{L0, L1};
    }

    public static SinglyLinkedNode[] split(SinglyLinkedList l) {
        return split(l.head());
    }

    public static SinglyLinkedNode[] split_iterative(SinglyLinkedNode n) {
        if (n == null || n.next() == null) {
            return new SinglyLinkedNode[]{n, null};
        }
        SinglyLinkedNode L0 = n;
        SinglyLinkedNode L1 = n.next();
        SinglyLinkedNode tail_L0 = L0;
        SinglyLinkedNode tail_L1 = L1;
        SinglyLinkedNode p = n.next().next();
        boolean is_pair = true;
        while (p != null) {
            if (is_pair) {
                tail_L0.setNext(p);
                tail_L0 = p;
            } else {
                tail_L1.setNext(p);
                tail_L1 = p;
            }
            p = p.next();
            is_pair ^= true; // XOR operation on is_pair, flips it around
        }
        if (is_pair) {
            tail_L0.setNext(null); // needed to remove trailing last element
        } else {
            tail_L1.setNext(null);
        }
        return new SinglyLinkedNode[]{L0, L1};
    }

    public static SinglyLinkedList fusion(SinglyLinkedList list0, SinglyLinkedList list1) throws IOException {
        if (list0.size() == 0) {
            return list1;
        }
        if (list1.size() == 0) {
            return list0;
        }
        SinglyLinkedNode lowest;
        if (list0.head().elem() < list1.head().elem()) {
            lowest = list0.removeFirst();
        } else {
            lowest = list1.removeFirst();
        }
        SinglyLinkedList fused_list = fusion(list0, list1);
        fused_list.addFirst(lowest);
        return fused_list;
    }

    public static SinglyLinkedList fusion_iterative(SinglyLinkedList list0, SinglyLinkedList list1) throws IOException {
        if (list0.size() == 0) {
            return list1;
        }
        if (list1.size() == 0) {
            return list0;
        }
        SinglyLinkedList fused_list = new SinglyLinkedList();
        while (list0.size() > 0 || list1.size() > 0) {
            if (list0.size() == 0) {
                fused_list.addLast(list1.removeFirst());
                continue;
            }
            if (list1.size() == 0) {
                fused_list.addLast(list0.removeFirst());
                continue;
            }
            if (list1.head().elem() < list0.head().elem()) {
                fused_list.addLast(list1.removeFirst());
            } else {
                fused_list.addLast(list0.removeFirst());
            }
        }
        return fused_list;
    }

    public static void pretty_print(SinglyLinkedNode n) {
        System.out.println(nodeToString(n));
    }

    public static String nodeToString(SinglyLinkedNode n) {
        if (n == null) {
            return "{}";
        }
        String str = "{";
        while (n.next() != null) {
            str += n.elem() + ", ";
            n = n.next();
        }
        str += n.elem() + "}";
        return str;
    }

    public static void pretty_print(SinglyLinkedList l) {
        pretty_print(l.head());
    }

    public static int[] sort3(int x, int y, int z) throws IOException {
        /*
         * Comme on n'a que 3 éléments, on peut énumérer les comparaisons.
         * Il y a maximum 3 comparaisons, et dans certains cas seulement 2.
         */
        if (x <= y) {
            if (y <= z) { // x <= y <= z
                return new int[]{x, y, z};
            } else { // x <=y, z < y
                if (x <= z) { // x <= z < y
                    return new int[]{x, z, y};
                } else { // z < x <= y
                    return new int[]{z, x, y};
                }
            }
        } else { // y < x
            if (z <= y) { // z <= y < x
                return new int[]{z, y, x};
            } else { // z > y, y < x
                if (x <= z) { // y < x <= z
                    return new int[]{y, x, z};
                } else { // y < z < x
                    return new int[]{y, z, x};
                }
            }
        }
    }

    public static int[] sort4(int w, int x, int y, int z) {
        /*
         * Ici ce serait peu lisible d'énumérer toutes les comparaisons (il y a 24 permutations possibles).
         * On doit trouver une autre stratégie. On remarque qu'on peut séparer les 4 éléments en 2 paires, les trier,
         * puis les recombiner. Entout, il y a 4 ou 5 comparaisons, 50% de chances chacun.
         */
        int[] t1 = new int[]{w, x};
        int[] t2 = new int[]{y, z};
        int tmp;
        sort2(t1); // 1 comparaison
        sort2(t2); // 2 comparaisons
        int[] t = new int[4];
        if (t1[0] <= t2[0]) { // 3 comparaisons
            t[0] = t1[0];
            if (t1[1] <= t2[0]) { // 4 comparaisons
                t[1] = t1[1]; t[2] = t2[0]; t[3] = t2[1]; return t; // total : 4
            } else {
                t[1] = t2[0];
                // continue en-dehors du premier if
            }
        } else {
            t[0] = t2[0];
            if (t2[1] <= t1[0]) { // 4 comparaisons
                t[1] = t2[1]; t[2] = t1[0]; t[3] = t1[1]; return t; // total : 4
            } else {
                t[1] = t1[0];
                //continue en-dehors du premier if
            }
        }
        if (t1[1] <= t2[1]) { // 5 comparaisons
            t[2] = t1[1]; t[3] = t2[1]; return t; // total : 5
        } else {
            t[2] = t2[1]; t[3] = t1[1]; return t; // total : 5
        }
    }

    public static int[] sort_bitonic(int[] b) {
        int[] t = new int[b.length];
        int i = 0;
        int j = b.length-1;
        int count = 0;
        while (i <= j) {
            if (b[i] <= b[j]) {
                t[count] = b[i];
                i++;
                count++;
            } else {
                t[count] = b[j];
                j--;
                count++;
            }
        }
        return t;
    }

    public static int[] make_bitonic(int n) {
        if (n <= 0) {
            n = 10;
        }
        int[] t = new int[n];
        t[0] = ThreadLocalRandom.current().nextInt(0, 11);
        if (n == 1) {
            return t;
        }
        int m = ThreadLocalRandom.current().nextInt(1, n);
        for (int i=1; i<m; i++) {
            t[i] = t[i-1] + ThreadLocalRandom.current().nextInt(0, 11);
        }
        for (int i=m; i<n; i++) {
            t[i] = t[i-1] - ThreadLocalRandom.current().nextInt(0, 11);
        }
        return t;
    }

    public static void sort2(int[] t) {
        /*
         * Trie 2 éléments avec une seule comparaison (trivial), dans un tableau de taille 2.
         */
        if (t[1] < t[0]) {
            int tmp = t[0]; t[0] = t[1]; t[1] = tmp;
        }
    }

    public static int[] insertion_sort_gamma(int[] t, int gamma) {
        int i = 1;
        int j;
        int tmp;
        while (i < t.length) {
            j = i;
            while (j > 0 && j > i-gamma && t[j-1] > t[j]) {
                tmp = t[j]; t[j] = t[j-1]; t[j-1] = tmp;
                j--;
            }
            i++;
        }
        return t;
    }

    public static int[][] vis_ecrou2(int[] vis, int[] ecrous) {
        if (vis[0] == ecrous[0]) {
            return new int[][]{vis, ecrous};
        } else {
            int tmp = vis[0]; vis[0] = vis[1]; vis[1] = tmp;
            return new int[][]{vis, ecrous};
        }
    }

    public static int[][] vis_ecrou3(int[] v, int[] e) {
        /*
         * À 3 éléments, c'est plus efficace de ne pas les trier. On cherche l'écrou correpondant à la première vis
         * (max 2 comparaisons), puis on compare une fois pour ranger la paire restante (max 3 comparaions au total)
         */
        if (v[0] == e[0]) {
            if (v[1] != e[1]) {
                swap(e, 1, 2);
            }
        } else if (v[0] == e[1]){
            if (v[1] == e[0]) {
                swap(e, 0, 1);
            } else {
                swap(e, 0, 1);
                swap(e, 1, 2);
            }
        } else if (v[1] == e[1]) { // v0 = e2
            swap(e, 0, 2);
        } else {
            swap(e, 0, 2);
            swap(e, 1, 2);
        }
        return new int[][]{v, e};
    }

    public static void swap(int[] t, int i, int j) {
        int tmp = t[i];
        t[i] = t[j];
        t[j] = tmp;
    }

    public static int compare_visecrou(int v, int e) {
        /*
         * Retourne 0 si v == e,
         *          1 si v < e,
         *          2 si v > e
         * Compte pour une seule comparaison ternaire.
         */
        if (v == e) {
            return 0;
        }
        if (v < e) {
            return 1;
        } else {
            return 2;
        }
    }

    public static String toString_2DArray(int[][] toprint) {
        String str = "[";
        for (int[] a : toprint) {
            str += Arrays.toString(a) + ", ";
        }
        str = str.substring(0, str.length()-2) + "]";
        return str;
    }

    public static void vis_ecrou_general(int[] v, int[] e) {
        vis_ecrou_general(v, e, 0, v.length-1);
    }

    public static void vis_ecrou_general(int[] v, int[] e, int low, int high) {
        /*
         * fortement inspiré de https://www.geeksforgeeks.org/nuts-bolts-problem-lock-key-problem/
         */
        if (low < high) {
            // on prend le dernier élément des vis pour trier les écrous
            int pivot_i = partition(e, low, high, v[high]);

            // on fait la même chose pour trier les vis
            partition(v, low, high, e[pivot_i]);

            // récursion sur les sous-tableaux restants
            vis_ecrou_general(v, e, low, pivot_i-1);
            vis_ecrou_general(v, e, pivot_i+1, high);
        }
    }

    public static int partition(int[] t, int low, int high, int pivot) {
        /*
         * fortement inspiré de https://www.geeksforgeeks.org/nuts-bolts-problem-lock-key-problem/
         */
        int i = low;
        for (int j=low; j<high; j++) {
            switch(compare_visecrou(t[j], pivot)) {
                case 0: // t[j] == pivot
                    swap(t, j, high);
                    j--;
                    break;
                case 1: // t[j] < pivot
                    swap(t, i, j);
                    i++;
            }
        }
        swap(t, i, high); // retourne le pivot à son indice
        return i;
    }

    public static void quicksort_iterative(int[] t) {
        quicksort_iterative(t, 0, t.length-1);
    }

    public static void quicksort_iterative(int[] t, int low, int high) {
        /*
         * fortement inspiré de https://www.geeksforgeeks.org/iterative-quick-sort/
         * la taille de la pile est O(n)
         */
        Stack<Integer> s = new Stack();
        s.push(low);
        s.push(high);
        int pivot_i;
        while (!s.isEmpty()) {
            high = s.pop();
            low = s.pop();
            pivot_i = partition(t, low, high, t[high]);
            if (pivot_i - 1 > low) { // au moins deux éléments à gauche du pivot
                s.push(low);
                s.push(pivot_i-1);
            }
            if (pivot_i + 1 < high) { // au moins deux éléments à droite du pivot
                s.push(pivot_i+1);
                s.push(high);
            }
        }
    }

    public static void quicksort_iterative_FIFO(int[] t) {
        quicksort_iterative_FIFO(t, 0, t.length-1);
    }

    public static void quicksort_iterative_FIFO(int[] t, int low, int high) {
        /*
         * fortement inspiré de https://www.geeksforgeeks.org/iterative-quick-sort/
         * la taille de la pile est O(n)
         */
        ArrayDeque<Integer> s = new ArrayDeque<>(); // file au lieu de pile
        s.addLast(low);
        s.addLast(high);
        int pivot_i;
        while (!s.isEmpty()) {
            low = s.removeFirst(); // il faut inverser low et high par rapport à la version avec stack
            high = s.removeFirst();
            pivot_i = partition(t, low, high, t[high]);
            if (pivot_i - 1 > low) { // au moins deux éléments à gauche du pivot
                s.addLast(low);
                s.addLast(pivot_i-1);
            }
            if (pivot_i + 1 < high) { // au moins deux éléments à droite du pivot
                s.addLast(pivot_i+1);
                s.addLast(high);
            }
        }
    }

    public static void quicksort_iterative_logn_stack(int[] t) {
        quicksort_iterative_logn_stack(t, 0, t.length-1);
    }

    public static void quicksort_iterative_logn_stack(int[] t, int low, int high) {
        /*
         * fortement inspiré de https://www.geeksforgeeks.org/iterative-quick-sort/
         * la taille de la pile est O(logn) (voir https://stackoverflow.com/questions/6709055/quicksort-stack-size pour discussion)
         */
        Stack<Integer> s = new Stack();
        s.push(low);
        s.push(high);
        int pivot_i;
        int left_size, right_size;
        while (!s.isEmpty()) {
            high = s.pop();
            low = s.pop();
            while (low+1 < high) {
                pivot_i = partition(t, low, high, t[high]);
                left_size = pivot_i - low;
                right_size = high - pivot_i;

                // on empile la plus grosse moitié et on continue d'itérer sur la petite
                if (right_size < left_size) {
                    s.push(low);
                    s.push(pivot_i - 1);
                    low = pivot_i + 1;
                } else { // le côté gauche est plus petit
                    s.push(pivot_i + 1);
                    s.push(high);
                    high = pivot_i-1;
                }
            }
        }
    }

    public static SinglyLinkedList make_random_sorted_list(int n) throws IOException {
        SinglyLinkedList list = new SinglyLinkedList();
        int r = ThreadLocalRandom.current().nextInt(0, 11);
        list.addLast(r);
        for (int i = 1; i < n; i++) {
            r += ThreadLocalRandom.current().nextInt(0, 11);
            list.addLast(r);
        }
        return list;
    }

    public static int total_size(SinglyLinkedList[] lists) {
        int s = 0;
        for (SinglyLinkedList l : lists) {
            s += l.size();
        }
        return s;
    }

    public static SinglyLinkedList fusion_k_listes(SinglyLinkedList[] lists) throws IOException {
        SinglyLinkedList fused_list = new SinglyLinkedList();
        TasBinaireSentinelles heap = new TasBinaireSentinelles();
        Item item;
        int i;
        for (i = 0; i < lists.length; i++) {
            if (lists[i].size() > 0) {
                heap.insert(new Item(lists[i].removeFirst().elem(), i));
            }
        }
        while (total_size(lists) > 0) {
            item = heap.deleteMin();
            fused_list.addLast((int) item.priority());
            i = (int) item.elem();
            if (lists[i].size() > 0) {
                heap.insert(new Item(lists[i].removeFirst().elem(), i));
            }
        }
        while (heap.size() > 0) {
            fused_list.addLast((int) heap.deleteMin().priority());
        }
        return fused_list;
    }

    public static void main(String[] args) throws IOException {
        // Exercice 2.3, Tris de liste chaînée (fichier PDF)
        System.out.println("Exercice 2.3, Tri de liste chaînée");
        SinglyLinkedList list = new SinglyLinkedList();
        for (int i=9; i>=0; i--) {
            list.addFirst(i);
        }
        System.out.print("Liste initiale : ");
        pretty_print(list);
        SinglyLinkedNode[] nodes = new SinglyLinkedNode[]{list.head()};
        for (int j=1; j<=5; j++) { // on appelle split sur la première des deux listes à plusieurs reprises pour tester
            System.out.println("split récursif, itération " + j);
            nodes = split(nodes[0]);
            System.out.print("L0 : ");
            pretty_print(nodes[0]);
            System.out.print("L1 : ");
            pretty_print(nodes[1]);
        }

        list = new SinglyLinkedList();
        for (int i=9; i>=0; i--) {
            list.addFirst(i);
        }
        System.out.print("Liste initiale : ");
        pretty_print(list);
        nodes = new SinglyLinkedNode[]{list.head()};
        for (int j=1; j<=5; j++) { // on teste le split itératif
            System.out.println("split itératif, itération " + j);
            nodes = split_iterative(nodes[0]);
            System.out.print("L0 : ");
            pretty_print(nodes[0]);
            System.out.print("L1 : ");
            pretty_print(nodes[1]);
        }
        list = new SinglyLinkedList();
        for (int i=9; i>=0; i--) {
            list.addFirst(i);
        }
        nodes = split(list);
        System.out.println("Listes initiales :");
        pretty_print(nodes[0]);
        pretty_print(nodes[1]);

        // on teste la fusion
        System.out.println("après fusion :");
        pretty_print(fusion(new SinglyLinkedList(nodes[0]), new SinglyLinkedList(nodes[1])));

        list = new SinglyLinkedList();
        for (int i=9; i>=0; i--) {
            list.addFirst(i);
        }
        nodes = split(list);
        System.out.println("Listes initiales :");
        pretty_print(nodes[0]);
        pretty_print(nodes[1]);
        // on teste la fusion itérative
        pretty_print(fusion_iterative(new SinglyLinkedList(nodes[0]), new SinglyLinkedList(nodes[1])));

        //Exercice t.1 (site du cours)
        System.out.println("\nExercice t.1");
        int w, x, y, z;
        w = ThreadLocalRandom.current().nextInt(0, 25);
        x = ThreadLocalRandom.current().nextInt(0, 25);
        y = ThreadLocalRandom.current().nextInt(0, 25);
        z = ThreadLocalRandom.current().nextInt(0, 25);
        System.out.println("3 valeurs à trier : " + x + ", " + y + ", " + z);
        System.out.println("Valeurs triées : " + Arrays.toString(sort3(x, y, z)));
        x = ThreadLocalRandom.current().nextInt(0, 25);
        y = ThreadLocalRandom.current().nextInt(0, 25);
        z = ThreadLocalRandom.current().nextInt(0, 25);
        System.out.println("4 valeurs à trier : " + w + ", " + x + ", " + y + ", " + z);
        System.out.println("Valeurs triées : " + Arrays.toString(sort4(w, x, y, z)));

        //Exercice t.2
        System.out.println("\nExercice t.2");
        int[] b = make_bitonic(10);
        System.out.println("Tableau bitonique : " + Arrays.toString(b));
        System.out.println("Tableau trié : " + Arrays.toString(sort_bitonic(b)));

        //Exercice t.3
        System.out.println("\nExercice t.3");
        int[] values = new int[]{2,3,1,6,5,9,4,8,7};
        int gamma = 3;
        System.out.println("Tableau initial (gamma = 3) : " + Arrays.toString(values));
        System.out.println("Tableau trié : " + Arrays.toString(insertion_sort_gamma(values, gamma)));

        System.out.println("Pour l'exercice t.3 b) voir la réponse à la question pq.5 de la démo 5. La solution est extrêmement similaire. (gamma = C-1)");

        //Exercice t.4
        System.out.println("\nExercice t.4");

        int[] v = new int[]{1, 2};
        int[] e = new int[]{2, 1};
        System.out.println("2 paires vis-écrou : " + Arrays.toString(v) + ", " + Arrays.toString(e));
        System.out.println("Triées : " + toString_2DArray(vis_ecrou2(v, e)));

        v = new int[]{1,2,3};
        e = new int[]{3,2,1};
        System.out.println("3 paires vis-écrou : " + Arrays.toString(v) + ", " + Arrays.toString(e));
        System.out.println("Triées : " + toString_2DArray(vis_ecrou3(v, e)));

        v = new int[]{1,2,3};
        e = new int[]{2,3,1};
        System.out.println("3 paires vis-écrou : " + Arrays.toString(v) + ", " + Arrays.toString(e));
        System.out.println("Triées : " + toString_2DArray(vis_ecrou3(v, e)));

        v = new int[]{1,2,3};
        e = new int[]{1,2,3};
        System.out.println("3 paires vis-écrou : " + Arrays.toString(v) + ", " + Arrays.toString(e));
        System.out.println("Triées : " + toString_2DArray(vis_ecrou3(v, e)));

        v = new int[]{1,2,3};
        e = new int[]{1,3,2};
        System.out.println("3 paires vis-écrou : " + Arrays.toString(v) + ", " + Arrays.toString(e));
        System.out.println("Triées : " + toString_2DArray(vis_ecrou3(v, e)));

        v = new int[]{9,8,7,3,4,2,5,6,1};
        e = new int[]{3,2,5,9,8,1,4,7,6};
        System.out.println("9 paires vis-écrou : " + Arrays.toString(v) + ", " + Arrays.toString(e));
        vis_ecrou_general(v, e);
        System.out.println("Triées : " + toString_2DArray(new int[][]{v, e}));

        System.out.println("\nExercice t.4 c) comme on chercher parmi n! permutations possibles des vis/écrous, \n" +
        "le meilleur arbre de décision possible aura une profondeur log(n!) ~= ((n+1)logn - n) = O(nlogn)");

        //Exercice t.5
        System.out.println("\nExercice t.5");
        int[] t = new int[]{3,2,5,9,8,1,4,7,6};
        System.out.println("tableau initial T: " + Arrays.toString(t));
        quicksort_iterative(t);
        System.out.println("a) T trié avec quicksort itératif (pile) : " + Arrays.toString(t));
        t = new int[]{3,2,5,9,8,1,4,7,6};
        quicksort_iterative_FIFO(t);
        System.out.println("b) remplacer la pile par une file fonctionne si on inverse l'assignation de low et high (voir algo)" +
                "\nT trié avec quicksort itératif (FIFO) : " + Arrays.toString(t));
        t = new int[]{3,2,5,9,8,1,4,7,6};
        quicksort_iterative_logn_stack(t);
        System.out.println("c) T trié avec quicksort itératif (pile de taille O(logn)) : " + Arrays.toString(t));

        //Exercice t.6
        System.out.println("\nExercice t.6");
        SinglyLinkedList[] lists = new SinglyLinkedList[5];
        for (int i=0; i<5;i++) {
            lists[i] = make_random_sorted_list(5);
            System.out.print("Liste " + i + " : ");
            pretty_print(lists[i]);
        }
        SinglyLinkedList fused_list = fusion_k_listes(lists);
        System.out.print("Liste fusionnée : ");
        pretty_print(fused_list);













    }
}
