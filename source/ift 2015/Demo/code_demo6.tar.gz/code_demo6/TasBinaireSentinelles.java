import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class TasBinaireSentinelles {

    private Item[] heap;
    private int size;
    private static final int C = 4;
    private static final double minus_inf = Double.NEGATIVE_INFINITY;
    private static final double inf = Double.POSITIVE_INFINITY;
    private static final double logOf2 = Math.log(2);

    public TasBinaireSentinelles() {
        heap = new Item[C];
        Arrays.fill(heap, new Item(inf, 0));
        heap[0] = new Item(minus_inf, 0);
        heap[0].setIndex(0);
        size = 0;
    }

    public int size() {
        return size;
    }

    public void insert(Item item) {
        if (size+2 == heap.length) {
            resize(2);
        }
        size++;
        swim(size, item);
    }

    public void insertCompareLess(Item item) {
        if (size+2 == heap.length) {
            resize(2);
        }
        size++;
        swimCompareLess(size, item);
    }

    private void swimCompareLess(int i, Item item) {
        ArrayList<Item> parents = new ArrayList<>();
        int j = i;
        while (j >= 0) { // takes O(logn), no comparison
            parents.add(heap[j]);
            if (j==0) {break;}
            j = parent(j);
        }
        int l = 0;
        int r = parents.size()-1;
        int m = 0; // dummy assignment
        while (l <= r) { // binary search. The candidate is a node which has higher priority than our item,
            // but with a parent of lower priority
            m = (l+r)/2;
            if (parents.get(m).priority() <= item.priority()) {
                r = m-1;
            } else if (parents.get(m+1).priority() <= item.priority()) {
                break;
            } else {
                l = m+1;
            }
        }
        for (j=0; j<m; j++) { // i is the initial index, and we sink down m nodes
            set(i, heap[parent(i)]);
            i = parent(i);
        }
        set(i, item); // finally we set the item in the identified position (mth ancestor of the last leaf)
    }

    private void swim(int i, Item item) {
        double p = item.priority();
        while (p < parent_pr(i)) {
            set(i, heap[parent(i)]);
            i = parent(i);
        }
        set(i, item);
    }



    public Item getMin() throws IOException {
        if (size < 1) {
            throw new IOException("getMin() called on empty heap!");
        }
        return heap[1];
    }

    public void delete(Item item) throws IOException {
        if (item == null) {
            throw new IOException("delete() called with null Item");
        }
        int i = item.index();
        if (i > size) {
            throw new IOException("delete() called with Item's index outside range");
        }
        Item leaf = heap[size];
        heap[size] = new Item(inf, 0);
        if (size > 1) {
            sink_or_swim(i, leaf);
        }
        size--;
        if (heap.length/(float) (size+1) > C) {
            resize(1/(float)C);
        }
    }

    private void sink_or_swim(int i, Item item) {
        double pr = item.priority();
        if (pr < parent_pr(i)) {
            swim(i, item);
        } else if (pr > lc_pr(i) || pr > rc_pr(i)) {
            sink(i, item);
        }
    }

    public Item deleteMin() {
        Item root = heap[1];
        Item leaf = heap[size];
        heap[size] = new Item(inf, 0);
        if (size > 1) {
            sink(1, leaf);
        }
        size--;
        if (heap.length/(float) (size+1) > C) {
            resize(1/(float)C);
        }
        return root;
    }

    private void sink(int i, Item item) {
        double p_l = lc_pr(i);
        double p_r = rc_pr(i);
        double p = item.priority();
        while (p > p_l || p > p_r) {
            if (p_r < p_l) {
                set(i, heap[right_child(i)]);
                i = right_child(i);
            }
            else {
                set(i, heap[left_child(i)]);
                i = left_child(i);
            }
            p_l = lc_pr(i);
            p_r = rc_pr(i);
        }
        set(i, item);
    }

    private void set(int i, Item item) {
        item.setIndex(i);
        heap[i] = item;
    }

    public ArrayList<Double> plus_petits(double k) {
        ArrayList<Double> l = new ArrayList<Double>();
        plus_petits(1, k, l);
        return l;
    }

    private void plus_petits(int i, double k, ArrayList<Double> l) {
        if (i < heap.length && heap[i].priority() <= k) {
            l.add(heap[i].elem());
            plus_petits(left_child(i), k, l);
            plus_petits(right_child(i), k, l);
        }
    }

    private void resize(float factor) {
        Item[] new_heap = new Item[(int)Math.ceil(heap.length*factor)];
        Arrays.fill(new_heap, new Item(inf, 0));
        int m = new_heap.length;
        for (int i = 0; i < size+1; i++) {
            new_heap[i] = heap[i];
        }
        heap = new_heap;
    }

    public String toString() {
        String s = "{";
        int i = 1;
        for (i = 1; i < heap.length-1; i++) {
            if (heap[i+1].priority() == inf) {
                break;
            }
            s += "(" + heap[i].priority() + "," + heap[i].elem() + "), ";
        }
        s += "(" + heap[i].priority() + "," + heap[i].elem() + ")}";
        return s;
    }

    public String pretty_print() {
        String s = "";
        int last_level = 0;
        int level = 0;
        for (int i=1; i<size+1; i++) {
            level = get_level(i);
            if (level != last_level) {
                s += "\n";
                last_level = level;
            }
            s += "(" + heap[i].priority() + "," + heap[i].elem() + ") ";
        }
        return s;
    }

    private int get_level(int i) {
        return (int) Math.floor(Math.log(i)/logOf2);
    }

    public String toStringFull() {
        String s = "{";
        for (int i = 0; i < heap.length-1; i++) {
            s += "(" + heap[i].priority() + "," + heap[i].elem() + "), ";
        }
        s += "(" + heap[heap.length-1].priority() + "," + heap[heap.length-1].elem() + ")}";
        return s;
    }

    private int parent(int i) {
        return i/2;
    }

    private double parent_pr(int i) {
        return heap[parent(i)].priority();
    }

    private int left_child(int i) {
        return 2*i;
    }

    private double lc_pr(int i) {
        if (left_child(i) > heap.length-1) {
            return inf;
        }
        return heap[left_child(i)].priority();
    }

    private int right_child(int i) {
        return 2*i + 1;
    }

    private double rc_pr(int i) {
        if (right_child(i) > heap.length-1) {
            return inf;
        }
        return heap[right_child(i)].priority();
    }

}
