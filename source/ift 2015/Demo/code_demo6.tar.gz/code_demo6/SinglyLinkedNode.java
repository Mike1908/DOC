
public class SinglyLinkedNode {

    private int element;
    private SinglyLinkedNode next;

    public SinglyLinkedNode(int e, SinglyLinkedNode n) {
        element = e;
        next = n;
    }

    public SinglyLinkedNode(int element) {
        this(element, null);
    }

    public SinglyLinkedNode next() {
        return next;
    }

    public int elem() {
        return element;
    }

    public void setNext(SinglyLinkedNode n) {
        next = n;
    }

    public void setElem(int e) {
        element = e;
    }
}
