public class Item {

    private double priority;
    private double element;
    private int index;

    public Item(double p, double e) {
        priority = p;
        element = e;
    }

    public double priority() {
        return priority;
    }

    public double elem() {
        return element;
    }

    public int index() {
        return index;
    }

    public void setPriority(double p) {
        priority = p;
    }

    public void setElement(double e) {
        element = e;
    }

    public void setIndex(int i) {
        index = i;
    }
}
