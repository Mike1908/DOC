import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;
import java.util.ArrayDeque;
import java.io.FileReader;


public class Demo5 {

    public static double minimax_naive(double[] A, int d) {
        double max = Double.NEGATIVE_INFINITY;
        double min;
        int n = A.length;
        for (int i = 0; i <= n-d; i++) {
            min = Double.POSITIVE_INFINITY;
            for (int j = i; j < i+d; j++) {
                if (A[j] < min) {
                    min = A[j];
                }
            }
            if (min > max) {
                max = min;
            }
        }
        return max;
    }

    public static double minimax_efficient(double[] A, int d) throws IOException {
        TasBinaireSentinelles heap = new TasBinaireSentinelles();
        Item last_item;
        ArrayDeque<Item> last_d = new ArrayDeque<>();
        for (int i = 0; i < d; i++) {
            last_item = new Item(A[i], A[i]);
            heap.insert(last_item);
            last_d.addLast(last_item);
        }
        double max = Double.NEGATIVE_INFINITY;
        double min;
        for (int i = d; i < A.length; i++) {
            min = heap.getMin().elem();
            if (min > max) {
                max = min;
            }
            heap.delete(last_d.removeFirst());
            last_item = new Item(A[i], A[i]);
            heap.insert(last_item);
            last_d.addLast(last_item);
        }
        return max;
    }

    public static int[][] make_interval_list(int n, int range, int offset) {
        if (range < 3) {
            range = 3;
        }
        int[][] interval_list = new int[n][2];
        int last_start = -1;
        for (int i=0; i<n; i++) {
            int r = ThreadLocalRandom.current().nextInt(last_start+1, last_start+offset+1);
            int q = ThreadLocalRandom.current().nextInt(r+1, r+range+1);
            interval_list[i][0] = r;
            interval_list[i][1] = q;
            last_start = r;
        }
        return interval_list;
    }

    public static int compute_C(int[][] interval_list) {
        int n = interval_list.length;
        int[] start = new int[n];
        int[] end = new int[n];
        for (int i=0; i<n; i++) {
            start[i] = interval_list[i][0];
            end[i] = interval_list[i][1];
        }
        return maxOverlapIntervalCount(start, end);
    }

    public static int[][] sort_intervals(int[][] intervals, int C) {
        TasBinaireSentinelles heap = new TasBinaireSentinelles();
        int n = intervals.length;
        int i;
        Item item;
        for (i=0; i<n+C+1; i++) {
            if (i>=C+1) {
                item = heap.deleteMin();
                intervals[i - C-1][0] = (int) item.elem();
                intervals[i - C-1][1] = (int) item.priority();
            }
            if (i<n) {
                heap.insert(new Item(intervals[i][1], intervals[i][0]));
            }
        }
        return intervals;
    }

    public static int maxOverlapIntervalCount(int[] start, int[] end){
        /*
         * Pris sur http://www.zrzahid.com/maximum-number-of-overlapping-intervals/
         */
        int maxOverlap = 0;
        int currentOverlap = 0;

        Arrays.sort(start);
        Arrays.sort(end);

        int i = 0;
        int j = 0;
        int m=start.length,n=end.length;
        while(i< m && j < n){
            if(start[i] <= end[j]){
                currentOverlap++;
                maxOverlap = Math.max(maxOverlap, currentOverlap);
                i++;
            }
            else{
                currentOverlap--;
                j++;
            }
        }
        return maxOverlap;
    }


    public static String toString_intervals(int[][] toprint) {
        String str = "[";
        for (int[] a : toprint) {
            str += Arrays.toString(a) + ", ";
        }
        str = str.substring(0, str.length()-2) + "]";
        return str;
    }

    public static void main(String[] args) throws IOException {
        TasBinaireSentinelles h = new TasBinaireSentinelles();
        int[] values = new int[]{4,7,2,9,7,4,1};

        //Exercice pq.1
//        System.out.println("\n***Exercice pq.1***");
//        for (int i =0; i<values.length; i++) {
//            h.insert(new Item((double) values[i], (double) i));
//        }
//        System.out.println(h.pretty_print());
//        for (int i = 0; i < 6; i++) {
//            h.deleteMin();
//            System.out.println();
//            System.out.println(h.pretty_print());
//        }


        //Exercice pq.2
//        System.out.println("\n***Exercice pq.2***");
//        h = new TasBinaireSentinelles();
//        for (int i =0; i<values.length; i++) {
//            h.insert(new Item((double) values[i], (double) i));
//        }
//        System.out.println(h.pretty_print());
//
//        System.out.println("plus petits que 4.0 :" + h.plus_petits(4.0));


        //Exercice pq.3
//        System.out.println("\n***Exercice pq.3***");
//        FilePrioriteBinaire fpb = new FilePrioriteBinaire();
//        for (int i=1; i<6; i++) {
//            int p = ThreadLocalRandom.current().nextInt(0, 2);
//            fpb.insert(p, (double) i);
//            System.out.print("(" + p + "," + (double) i + ") ");
//        }
//        System.out.println();
//        for (int i=1; i<6; i++) {
//            System.out.println(fpb.removeMin());
//        }


//        //Exercice pq.4
//        System.out.println("\n***Exercice pq.4***");
//        double[] A = new double[10];
//        for (int i =0; i < 10; i++) {
//            A[i] = ThreadLocalRandom.current().nextDouble(0, 100);
//        }
//        System.out.println(Arrays.toString(A));
//        System.out.println("minimax with d=3: " + minimax_efficient(A, 3));

//
//        //Exercice pq.5
//        System.out.println("\n***Exercice pq.5***");
//        int[][] interval_list = make_interval_list(10, 50, 5);
//        System.out.println(toString_intervals(interval_list));
//        int C = compute_C(interval_list);
//        System.out.println(C);
//        sort_intervals(interval_list, C);
//        System.out.println(toString_intervals(interval_list));
//
//
//        //Exercice pq.6
        System.out.println("\n***Exercice pq.6***");
        h = new TasBinaireSentinelles();
        for (int i =0; i<values.length; i++) {
            h.insertCompareLess(new Item((double) values[i], (double) i));
        }
        System.out.println(h.pretty_print());
        for (int i = 0; i < 6; i++) {
            h.deleteMin();
            System.out.println();
            System.out.println(h.pretty_print());
        }
    }
}