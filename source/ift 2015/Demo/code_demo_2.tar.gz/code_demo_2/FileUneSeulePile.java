
import java.io.IOException;

public class FileUneSeulePile {

    private Stack s;

    public FileUneSeulePile() {
        s = new Stack<Integer>();
    }

    public void enqueue(int x) {
        s.push(x);
    }

    public int dequeue() throws IOException {
        if (s.size() < 1) {
            throw new IOException("called dequeue on empty queue");
        }
        return get_bottom();
    }

    private int get_bottom() {
        if (s.size() == 1) {
            return (int) s.pop();
        }
        int tmp = (int) s.pop();
        int bottom = get_bottom();
        s.push(tmp);
        return bottom;
    }

    public static void main(String[] args) throws IOException {
        FileUneSeulePile test = new FileUneSeulePile();
        int[] values = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (int v: values) {
            test.enqueue(v);
        }
        for (int v: values) {
            System.out.println(test.dequeue());
        }
    }




}
