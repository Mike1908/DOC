import java.util.*;
import java.util.concurrent.ThreadLocalRandom;


public class Demo2 {

//            int p = ThreadLocalRandom.current().nextInt(0, size);
//            int q = ThreadLocalRandom.current().nextInt(0, size);


    public static ArrayList<Integer> find_local_maxes(int[] t) {
        ArrayList<Integer> maxes = new ArrayList<>();
        if (t.length < 3) {
            return maxes;
        }
        int prev = t[0];
        int next;
        int x = t[1];
        for (int i = 1; i < t.length-1; i++) {
            next = t[i+1];
            if (prev < x && next < x) {
                maxes.add(x);
            }
            prev = x;
            x = next;
        }
        return maxes;
    }

    public static ArrayList<Integer> find_local_maxes_skip(int[] t) {
        ArrayList<Integer> maxes = new ArrayList<>();
        if (t.length < 3) {
            return maxes;
        }
        int prev = t[0];
        int next;
        int x = t[1];
        for (int i = 1; i < t.length-2; i++) {
            next = t[i+1];
            if (prev < x && next < x) {
                maxes.add(x);
                prev = next;
                x = t[i+2];
                i++;
            } else {
                prev = x;
                x = next;
            }
        }
        if (t[t.length-3] < t[t.length-2] && t[t.length-1] < t[t.length-2]) {
            maxes.add(t[t.length-2]);
        }
        return maxes;
    }

    public static int suppress_x(int[] t, int x) {
        int offset = 0;
        for (int i = 0; i < t.length; i++) {
            if (t[i] == x) {
                offset++;
            } else if (offset > 0) {
                t[i-offset] = t[i];
            }
        }
        return t.length-offset;
    }

    public static int suppress_x_alternate(int[] t, int x) {
        int offset = 0;
        for (int i = 0; i < t.length; i++) {
            if (t[i] == x) {
                offset++;
            } else {
                t[i-offset] = t[i];
            }
        }
        return t.length-offset;
    }

    public static int GCD(int u, int v) {
        // Taken from https://en.wikipedia.org/wiki/Binary_GCD_algorithm
        if (u == v) {
            return u;
        }
        if (u == 0) {
            return v;
        }
        if (v == 0) {
            return u;
        }
        if ((u & 1) == 0) { // u is even
            if ((v & 1) == 1) { // v is odd
                return GCD(u >> 1, v);
            } else { // u and v even
                return GCD(u >> 1, v >> 1) << 1;
            }

        }
        if ((v & 1) == 0) { // u odd, v even
            return GCD(u, v >> 1);
        }

        //reduce larger argument
        if (u > v) {
            return GCD((u-v) >> 1, v);
        }

        return GCD((v-u) >> 1, u);
    }

    public static void decalage_circulaire(int[] t, int delta) {
        // inspiré par https://stackoverflow.com/a/32698823
        if (t.length <= 1) {
            return;
        }
        delta = delta % t.length; // on s'assure que delta < longueur de t
        delta = t.length - delta; // plus simple conceptuellement de faire un décalage vers la gauche
        int gcd = GCD(t.length, delta);
        System.out.println(gcd);
        int tmp, i, k;
        for (int c = 0; c < gcd; c++) {
            i = c;
            tmp = t[i];
            while (true) {
                k = (i + delta) % t.length;
                if (k == c) {
                    break;
                }
                t[i] = t[k];
                i = k;
            }
            t[i] = tmp;
        }
    }


//    public float test_UF() {
//        long startTime = System.nanoTime();
//        long endTime = System.nanoTime();
//        return (endTime - startTime)/1000000f;
//    }



    public static void main(String[] args) {
        int[] values = new int[]{1, 2, 3, 2, 5, 4, 7, 2, 2, 10};
        // Exercice 1.1
        System.out.println(find_local_maxes(values));

        // Exercice 1.2
        System.out.println(Arrays.toString(values));
        System.out.println(suppress_x(values, 2));
        System.out.println(Arrays.toString(values));

        // Exercice 1.3



        values = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        Demo2.decalage_circulaire(values, 9);
        System.out.println(Arrays.toString(values));
    }
}
