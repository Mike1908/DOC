
public class TableauFIFO {

    private int[] t;
    private int n = 0;
    private int start = 0;

    public TableauFIFO() {
        this(10);
    }
    public TableauFIFO(int taille_init) {

        t = new int[taille_init];
    }

    public void enqueue(int x) {
        if (n+1 > t.length) {
            this.resize(2);
        }
        int i = start + n % t.length;
        t[i] = x;
        n++;
    }

    public int dequeue() {
        int x = t[start];
        if (n-1 < t.length/4f) {
            this.resize(0.5f);
        }
        start = (start + 1) % t.length;
        n -= 1;
        return x;
    }

    private void resize(float factor) {
        int[] new_t = new int[(int)Math.ceil(t.length*factor)];
        int m = new_t.length;
        for (int i = start; i < start+n; i++) {
            new_t[i % m] = t[i % t.length];
        }
        t = new_t;
        start = start % m;
    }

    public int size() {
        return n;
    }

    public int capacity() {
        return t.length;
    }

    public static void main(String[] args) {
        TableauFIFO test = new TableauFIFO();
        int[] values = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (int v : values) {
            test.enqueue(v);
            System.out.println("size: " + test.size() + " capacity: " + test.capacity());
        }
        for (int v : values) {
            System.out.println("element: " + test.dequeue() + " size: " + test.size() + " capacity: " + test.capacity());
        }
    }


}
