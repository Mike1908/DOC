import java.io.IOException;

public class FileDeuxPiles{

    private Stack s1;
    private Stack s2;

    public FileDeuxPiles() {
        s1 = new Stack();
        s2 = new Stack();
    }

    public void enqueue(int x) {
        s1.push(x);
    }

    public int size() {
        return s1.size() + s2.size();
    }

    public int dequeue() throws IOException {
        if (s2.size() == 0) {
            if (s1.size() == 0) {
                throw new IOException("dequeue called on empty queue");
            }
            while (s1.size() > 1) {
                s2.push(s1.pop());
            }
            return (int) s1.pop();
        }
        return (int) s2.pop();
    }

    public void defile(int k) throws IOException {
        if (k > this.size()) {
            throw new IOException("defile called with k > size!");
        }
        while (k > 0) {
            this.dequeue();
            k--;
        }
    }

    public static void main(String[] args) throws IOException{
        FileDeuxPiles test = new FileDeuxPiles();
        int[] values = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (int v: values) {
            test.enqueue(v);
        }
        for (int v: values) {
            System.out.println(test.dequeue());
        }
    }

}
