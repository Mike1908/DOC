/**
 * A node in a singly linked list
 */
public class Node {
    private int element;
    private Node next;

    public Node(int elem) {
        this.element = elem;
        this.next = null;
    }

    public Node(int elem, Node n) {
        this.element = elem;
        this.next = n;
    }

    public int elem() {
        return this.element;
    }

    public Node next() {
        return this.next;
    }

    public void set_next(Node n) {
        this.next = n;
    }

    public void set_elem(int e) {
        this.element = e;
    }
}

