import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;

public class Demo3 {
    
    public static Node search(Node head, int y) {
        if (head.elem() == y) {
            return head;
        }
        Node p = head.next();
        Node prev = head;
        Node tmp;
        while (p != null) {
            if (p.elem() == y) {
                prev.set_next(p.next());
                tmp = head;
                head = p;
                head.set_next(tmp);
            }
            prev = p;
            p = p.next();
        }
        return head;
    }

    public static Node ListPerm(Node x, int n) {
        int i, j;
        Node p = x;
        Node q;
        int tmp;
        for (i = 0; i < n-1; i++) {
            j = ThreadLocalRandom.current().nextInt(i, n);
            q = p;
            while (j < i+1) {
                q = q.next();
            }
            tmp = q.elem();
            q.set_elem(p.elem());
            p.set_elem(tmp);
            p = p.next();
        }
        return x;
    }

    public static SinglyLinkedList RiffleShuffle(SinglyLinkedList l) {
        Node head_a, head_b;
        Node p = l.head();
        Node q = p;
        head_a = p;
        Node prev = p;
        while (p.next() != null && q.next() != null && q.next().next() != null) {
            prev = p;
            p = p.next();
            q = q.next().next();
        }
        head_b = p;
        prev.set_next(null);
        SinglyLinkedList m = new SinglyLinkedList();
        int r;
        while (head_a != null || head_b != null) {
            r = ThreadLocalRandom.current().nextInt(0, 2);
            if (r == 0 && head_a != null) {
                m.add_first(head_a.elem());
                head_a = head_a.next();
            } else if (head_b != null){
                m.add_first(head_b.elem());
                head_b = head_b.next();
            }
        }
        l = m;
        return l;
    }

    public static SinglyLinkedList FullPermutationShuffle(SinglyLinkedList l) {
        for (int i = 0; i < 7; i++) {
            l = RiffleShuffle(l);
        }
        return l;
    }

    public static SinglyLinkedList getCardDeck() {
        SinglyLinkedList card_deck = new SinglyLinkedList();
        for (int i = 1; i < 53; i++) {
            card_deck.add_last(i);
        }
        return card_deck;
    }

    public static void fuseCircularLists(CircularList m, CircularList l) throws IOException {
        if (l.size() == 0 && m.size() == 0) {
            throw new IOException("Called fuseCircularLists with two empty lists");
        }
        if (l.size() == 0) {
            l.setLast(m.last());
            l.setSize(m.size());
        }
        if (m.size() == 0) {
            m.setLast(l.last());
            m.setSize(l.size());
        }
        Node tmp = l.last().next();
        l.last().set_next(m.last().next());
        m.last().set_next(tmp);
        int newsize = m.size() + l.size();
        m.setSize(newsize);
        l.setSize(newsize);
    }

    public static void main(String[] args) throws IOException {
        SinglyLinkedList test = new SinglyLinkedList();
        for (int i = 10; i > 5; i--) {
            test.add_first(i);
        }
        Node n = new Node(5);
        test.add_first(n);
        for (int i = 4; i > 0; i--) {
            test.add_first(i);
        }
        // Exercice 1.1
        System.out.println("***Exercice 1.1***");
        System.out.println(test.toString());
        test.exchange(n);
        System.out.println(test.toString());
        test.exchangeData(n);
        System.out.println(test.toString());

        // Exercice 1.2
        System.out.println("\n***Exercice 1.2***");
        System.out.println(test.toString());
        test.inversion_iteration();
        System.out.println(test.toString());
        test.inversion_recursion();
        System.out.println(test.toString());

        // Exercice 1.3
        System.out.println("\n***Exercice 1.3***");
        CircularList cir_list = new CircularList();
        for (int i = 10; i > 0; i--) {
            cir_list.add_first(i);
        }
        System.out.println(cir_list.toString());
        CircularList cir_list2 = new CircularList();
        for (int i = 20; i > 10; i--) {
            cir_list2.add_first(i);
        }
        System.out.println(cir_list2.toString());
        fuseCircularLists(cir_list, cir_list2);
        System.out.println(cir_list.toString());
        System.out.println(cir_list2.toString());

        // Exercice 1.4
        System.out.println("\n***Exercice 1.4***");
        SinglyLinkedList l = getCardDeck();
        System.out.println(l.toString());
        int[] searches = new int[]{7,4,13,40,2,6};
        for (int s : searches) {
            l.setHead(search(l.head(), s));
        }
        System.out.println(l);

        // Exercice 1.5
        System.out.println("\n***Exercice 1.5***");
        SinglyLinkedList card_deck = getCardDeck();
        System.out.println(card_deck.toString());
        card_deck = FullPermutationShuffle(card_deck);
        System.out.println(card_deck.toString());
    }
}
