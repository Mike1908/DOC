/**
 * Created by Paracelsus on 2019-01-23.
 */
public class CircularList {
    private Node last;
    private int size;

    public CircularList() {
        size = 0;
        last = null;
    }

    public void add_first(int x) {
        if (size == 0) {
            last = new Node(x);
            last.set_next(last);
        } else {
            Node tmp = last.next();
            last.set_next(new Node(x));
            last.next().set_next(tmp);
        }
        size++;
    }

    public int size() {
        return size;
    }

    public Node last() {
        return last;
    }

    public void setLast(Node newlast) {
        last = newlast;
    }

    public void setSize(int newsize) {
        size = newsize;
    }

    public String toString() {
        if (size == 0) {
            return "{}";
        }
        Node head = last.next();
        if (size == 1) {
            return "{" + head.elem() + "}";
        }
        String s = "{";
        Node p = head;
        while (p.next() != head) {
            s += p.elem() + ", ";
            p = p.next();
        }
        s += p.elem() + "}";
        return s;
    }

}
