import java.io.IOException;

/**
 * A singly linked list using Node objects (can only store int values, for simplicity)
 */
public class SinglyLinkedList {
    private int size;
    private Node head;

    public SinglyLinkedList() {
        size = 0;
        head = null;
    }

    public SinglyLinkedList(Node n) {
        head = n;
        size = calcSize();
    }

    public SinglyLinkedList(Node n, int s) {
        head = n;
        size = s;
    }

    public Node head() {
        return head;
    }

    public void setHead(Node newhead) {
        head = newhead;
    }

    private int calcSize() {
        Node p = head;
        int s = 1;
        while (p.next() != null) {
            p = p.next();
            s++;
        }
        return s;
    }

    public String toString() {
        if (size == 1) {
            return "{" + head.elem() + "}";
        }
        if (size == 0) {
            return "{}";
        }
        String s = "{";
        Node p = head;
        while (p.next() != null) {
            s += p.elem() + ", ";
            p = p.next();
        }
        s += p.elem() + "}";
        return s;
    }

    public void add_last(int x) {
        if (size == 0) {
            head = new Node(x);
            size = 1;
            return;
        }
        Node p = head;
        while (p.next() != null) {
            p = p.next();
        }
        p.set_next(new Node(x));
        size++;
    }

    public void add_first(int x) {
        Node tmp = head;
        head = new Node(x, tmp);
        size++;
    }

    public void add_first(Node x) {
        Node tmp = head;
        head = x;
        head.set_next(tmp);
        size++;
    }

    public Node remove_first() throws IOException {
        if (size == 0) {
            throw new IOException("Trying to remove head node from empty list");
        }
        Node n = head;
        head = head.next();
        size--;
        return n;
    }

    public Node remove_last() throws IOException {
        if (size == 0) {
            throw new IOException("Trying to remove head node from empty list");
        }
        Node p = head;
        if (p.next() == null) {
            size = 0;
            head = null;
            return p;
        }
        while (p.next().next() != null) {
            p = p.next();
        }
        Node n = p.next();
        p.set_next(null);
        size--;
        return n;
    }

    public void exchange(Node n) throws IOException {
        if (n == null || n.next() == null || n.next().next() == null) {
            throw new IOException("called exchange on node without two successors");
        }
        Node tmp = n.next();
        n.set_next(n.next().next());
        tmp.set_next(n.next().next());
        n.next().set_next(tmp);
    }

    public void exchangeData(Node n) throws IOException {
        if (n == null || n.next() == null || n.next().next() == null) {
            throw new IOException("called exchange on node without two successors");
        }
        int tmp = n.next().next().elem();
        n.next().next().set_elem(n.next().elem());
        n.next().set_elem(tmp);
    }

    public void inversion_iteration() {
        if (size < 2) {
            return;
        }
        Node prev = head;
        Node p = head.next();
        Node next;
        prev.set_next(null);
        while (p.next() != null) {
            next = p.next();
            p.set_next(prev);
            prev = p;
            p = next;
        }
        p.set_next(prev);
        head = p;
    }

    public void inversion_recursion() {
        Node p = head.next();
        head.set_next(null);
        inversion_recursion_helper(head, p);
    }

    public void inversion_recursion_helper(Node prev, Node n) {
        if (n.next() == null) {
            head = n;
            n.set_next(prev);
        } else {
            Node next = n.next();
            n.set_next(prev);
            inversion_recursion_helper(n, next);
        }
    }







}

