import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by Paracelsus on 2019-01-09.
 */
public class RandomGraph {

    private int size;
    private Set<List<Integer>> edges = new HashSet();
    public int count;

    public RandomGraph(int n_vertices, int n_random_edges) {
        size = n_vertices;
        while (edges.size() < n_random_edges) {
            int p = ThreadLocalRandom.current().nextInt(0, size);
            int q = ThreadLocalRandom.current().nextInt(0, size);
            List<Integer> e = new ArrayList();
            if (p > q) {
                e.add(q);
                e.add(p);
            } else {
                e.add(p);
                e.add(q);
            }
            edges.add(e);
        }
    }

    public void print_edges() {
        for (List e : edges) {
            System.out.println(e.get(0) + " " + e.get(1));
        }
    }

    public int run_UF() {
        UF uf = new UF(size);
        for (List<Integer> e : edges) {
            int p = e.get(0);
            int q = e.get(1);
            if (uf.connected(p, q)) continue;
            uf.union(p, q);
        }
        return uf.count();
    }

    public float test_UF() {
        long startTime = System.nanoTime();
        count = run_UF();
        long endTime = System.nanoTime();
        return (endTime - startTime)/1000000;
    }



    public static void main(String[] args) {
        RandomGraph rg = new RandomGraph(4000000, 8000000);
        System.out.println(rg.test_UF());
        System.out.println(rg.count);


    }
}
